<?php
/**
 * ╔══════════════════════════════════════════════════╗
 * ║         DEPLOYMENT HEALTH CHECK TOOL            ║
 * ║  Upload ke backend server, akses via browser.   ║
 * ║  HAPUS file ini setelah selesai diagnosa!        ║
 * ╚══════════════════════════════════════════════════╝
 */

// ── Keamanan dasar: bisa diproteksi dengan token ────────────────────────────
// Uncomment baris di bawah dan ganti tokennya untuk keamanan lebih:
// if (($_GET['token'] ?? '') !== 'ganti-token-rahasia-ini') { http_response_code(403); die('Forbidden'); }

// ── Load .env ────────────────────────────────────────────────────────────────
$env = [];
foreach ([__DIR__ . '/.env', __DIR__ . '/../.env'] as $envPath) {
    if (file_exists($envPath)) {
        foreach (file($envPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
            if (str_starts_with(trim($line), '#') || !str_contains($line, '=')) continue;
            [$k, $v] = explode('=', $line, 2);
            $env[trim($k)] = trim($v);
        }
        break;
    }
}

// ── Hasil checks ─────────────────────────────────────────────────────────────
$results = [];

function ok(string $label, string $detail = ''): array {
    return ['status' => 'ok', 'label' => $label, 'detail' => $detail];
}
function warn(string $label, string $detail = ''): array {
    return ['status' => 'warn', 'label' => $label, 'detail' => $detail];
}
function fail(string $label, string $detail = ''): array {
    return ['status' => 'fail', 'label' => $label, 'detail' => $detail];
}

// ── 1. PHP Version ───────────────────────────────────────────────────────────
$phpVer = PHP_VERSION;
$results['php'] = version_compare($phpVer, '8.0', '>=')
    ? ok("PHP Version: $phpVer", "✓ PHP 8.0+ terdeteksi")
    : fail("PHP Version: $phpVer", "✗ Butuh minimal PHP 8.0");

// ── 2. File .env ─────────────────────────────────────────────────────────────
$results['env'] = !empty($env)
    ? ok(".env ditemukan", "Keys: " . implode(', ', array_keys($env)))
    : fail(".env tidak ditemukan", "Pastikan file .env ada di folder backend");

// ── 3. Database Connection ───────────────────────────────────────────────────
try {
    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
        $env['DB_HOST'] ?? 'localhost',
        $env['DB_PORT'] ?? '3306',
        $env['DB_NAME'] ?? ''
    );
    $pdo = new PDO($dsn, $env['DB_USER'] ?? '', $env['DB_PASS'] ?? '', [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_TIMEOUT => 5,
    ]);

    // Cek tabel-tabel yang dibutuhkan
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    $required = ['users', 'project_records', 'import_batches', 'datasets', 'audit_logs'];
    $missing  = array_diff($required, $tables);

    if (empty($missing)) {
        $results['db'] = ok("Database terhubung", "DB: {$env['DB_NAME']} | Tabel: " . implode(', ', $tables));
    } else {
        $results['db'] = warn("Database terhubung, tapi ada tabel yang kurang", "Missing: " . implode(', ', $missing) . ". Jalankan migrations.sql");
    }

    // Cek jumlah user
    $userCount = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $results['db_users'] = $userCount > 0
        ? ok("Users di database: $userCount", "Ada akun yang bisa login")
        : warn("Tidak ada user di database", "Import migrations.sql atau jalankan seeder");

} catch (PDOException $e) {
    $results['db'] = fail("Database gagal terhubung", $e->getMessage());
    $results['db_users'] = fail("Skip (DB gagal)", "");
}

// ── 4. FRONTEND_URL / CORS ───────────────────────────────────────────────────
$frontendUrl = $env['FRONTEND_URL'] ?? '';
$origin      = $_SERVER['HTTP_ORIGIN'] ?? $_SERVER['HTTP_REFERER'] ?? '(tidak ada - akses langsung)';

if (empty($frontendUrl)) {
    $results['cors'] = fail("FRONTEND_URL kosong", "Set FRONTEND_URL di .env");
} else {
    $allowed = array_map('trim', explode(',', $frontendUrl));
    $results['cors'] = ok(
        "FRONTEND_URL: $frontendUrl",
        "Origin request saat ini: $origin | Allowed: " . implode(', ', $allowed)
    );
}

// ── 5. PHP Extensions ────────────────────────────────────────────────────────
$exts = ['pdo', 'pdo_mysql', 'json', 'mbstring', 'fileinfo', 'zip'];
$missingExts = array_filter($exts, fn($e) => !extension_loaded($e));
$results['extensions'] = empty($missingExts)
    ? ok("PHP Extensions OK", "Loaded: " . implode(', ', $exts))
    : fail("Extension kurang: " . implode(', ', $missingExts), "Aktifkan di php.ini atau cPanel → PHP Extensions");

// ── 6. Folder uploads ────────────────────────────────────────────────────────
$uploadsDir = __DIR__ . '/uploads';
$tempDir    = __DIR__ . '/uploads/temp';

if (!is_dir($uploadsDir)) {
    $results['uploads'] = fail("Folder uploads/ tidak ada", "Buat folder uploads/ dan uploads/temp/");
} elseif (!is_writable($uploadsDir)) {
    $results['uploads'] = fail("Folder uploads/ tidak writable", "chmod 755 uploads/");
} elseif (!is_dir($tempDir)) {
    $results['uploads'] = warn("Folder uploads/temp/ tidak ada", "Buat folder: mkdir uploads/temp && chmod 755 uploads/temp");
} elseif (!is_writable($tempDir)) {
    $results['uploads'] = warn("uploads/temp/ tidak writable", "chmod 755 uploads/temp/");
} else {
    $results['uploads'] = ok("Folder uploads/ & uploads/temp/ OK", "Writable ✓");
}

// ── 7. Composer vendor/ ──────────────────────────────────────────────────────
$vendorAutoload = __DIR__ . '/vendor/autoload.php';
$results['vendor'] = file_exists($vendorAutoload)
    ? ok("vendor/autoload.php ditemukan", "Composer dependencies terinstall")
    : fail("vendor/ tidak ditemukan", "Jalankan: composer install --no-dev, atau upload folder vendor/");

// ── 8. Cek PhpSpreadsheet (untuk import Excel) ───────────────────────────────
if (file_exists($vendorAutoload)) {
    require_once $vendorAutoload;
    $results['spreadsheet'] = class_exists('\PhpOffice\PhpSpreadsheet\Spreadsheet')
        ? ok("PhpSpreadsheet tersedia", "Import Excel/CSV akan berfungsi")
        : fail("PhpSpreadsheet tidak ditemukan", "Jalankan: composer require phpoffice/phpspreadsheet");
} else {
    $results['spreadsheet'] = warn("Skip (vendor/ tidak ada)", "");
}

// ── 9. HTTPS ─────────────────────────────────────────────────────────────────
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
           || (($_SERVER['SERVER_PORT'] ?? 80) == 443)
           || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
$results['https'] = $isHttps
    ? ok("HTTPS aktif", "Session cookie SameSite=None akan bekerja → cross-origin login OK")
    : warn("HTTPS tidak terdeteksi", "Cookie Secure=true hanya bekerja di HTTPS. Login cross-origin mungkin gagal.");

// ── 10. Session ──────────────────────────────────────────────────────────────
session_start();
$_SESSION['check_test'] = 'ok';
$results['session'] = (session_status() === PHP_SESSION_ACTIVE)
    ? ok("Session berjalan", "Session ID: " . session_id())
    : fail("Session gagal", "Cek php.ini session.save_path");

// ── 11. API endpoint me.php ──────────────────────────────────────────────────
$meFile = __DIR__ . '/api/auth/me.php';
$results['api_me'] = file_exists($meFile)
    ? ok("api/auth/me.php ada", "File exists ✓")
    : fail("api/auth/me.php tidak ditemukan", "Pastikan semua folder api/ sudah terupload");

// ── 12. Hitung total file API ─────────────────────────────────────────────────
$apiDir = __DIR__ . '/api';
if (is_dir($apiDir)) {
    $phpFiles = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($apiDir));
    $count = iterator_count(new RegexIterator($phpFiles, '/\.php$/'));
    $results['api_files'] = ok("API files: $count .php file ditemukan", "di folder api/");
} else {
    $results['api_files'] = fail("Folder api/ tidak ditemukan", "Upload folder api/ ke server");
}

// ── Hitung skor ──────────────────────────────────────────────────────────────
$total  = count($results);
$oks    = count(array_filter($results, fn($r) => $r['status'] === 'ok'));
$warns  = count(array_filter($results, fn($r) => $r['status'] === 'warn'));
$fails  = count(array_filter($results, fn($r) => $r['status'] === 'fail'));
$score  = round(($oks / $total) * 100);

?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Deployment Health Check</title>
<style>
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Segoe UI', system-ui, sans-serif;
    background: #0f0f13;
    color: #e2e8f0;
    min-height: 100vh;
    padding: 2rem 1rem;
  }
  .container { max-width: 780px; margin: 0 auto; }

  /* Header */
  .header {
    text-align: center;
    margin-bottom: 2rem;
  }
  .header h1 {
    font-size: 1.6rem;
    font-weight: 700;
    background: linear-gradient(135deg, #38bdf8, #818cf8);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin-bottom: .4rem;
  }
  .header p { color: #64748b; font-size: .875rem; }

  /* Score */
  .score-card {
    background: #1e1e2e;
    border: 1px solid #2a2a3a;
    border-radius: 16px;
    padding: 1.5rem;
    margin-bottom: 1.5rem;
    display: flex;
    align-items: center;
    gap: 1.5rem;
  }
  .score-circle {
    width: 88px; height: 88px;
    border-radius: 50%;
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    font-weight: 800; flex-shrink: 0;
    border: 3px solid;
  }
  .score-circle.great  { border-color: #22c55e; color: #22c55e; background: #22c55e12; }
  .score-circle.warn   { border-color: #f59e0b; color: #f59e0b; background: #f59e0b12; }
  .score-circle.danger { border-color: #ef4444; color: #ef4444; background: #ef444412; }
  .score-circle .num   { font-size: 1.8rem; line-height: 1; }
  .score-circle .pct   { font-size: .75rem; opacity: .7; }
  .score-info h2       { font-size: 1.1rem; font-weight: 600; margin-bottom: .5rem; }
  .badges { display: flex; gap: .5rem; flex-wrap: wrap; }
  .badge {
    font-size: .75rem; font-weight: 600;
    padding: .2rem .6rem; border-radius: 99px;
  }
  .badge.ok   { background: #22c55e22; color: #4ade80; }
  .badge.warn { background: #f59e0b22; color: #fbbf24; }
  .badge.fail { background: #ef444422; color: #f87171; }

  /* Items */
  .section-title {
    font-size: .7rem; font-weight: 700; letter-spacing: .1em;
    color: #475569; text-transform: uppercase;
    margin-bottom: .75rem;
  }
  .check-list { display: flex; flex-direction: column; gap: .5rem; margin-bottom: 2rem; }
  .check-item {
    background: #1e1e2e;
    border: 1px solid #2a2a3a;
    border-radius: 10px;
    padding: .85rem 1rem;
    display: flex;
    align-items: flex-start;
    gap: .85rem;
    transition: border-color .15s;
  }
  .check-item:hover { border-color: #3a3a50; }
  .icon {
    width: 28px; height: 28px; border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1rem; flex-shrink: 0; margin-top: .05rem;
  }
  .icon.ok   { background: #22c55e18; }
  .icon.warn { background: #f59e0b18; }
  .icon.fail { background: #ef444418; }
  .check-body { flex: 1; min-width: 0; }
  .check-label {
    font-size: .875rem; font-weight: 600; color: #e2e8f0;
    margin-bottom: .2rem;
  }
  .check-detail {
    font-size: .775rem; color: #64748b;
    word-break: break-all;
    line-height: 1.5;
  }
  .pill {
    display: inline-block; font-size: .65rem; font-weight: 700;
    padding: .1rem .45rem; border-radius: 4px;
    text-transform: uppercase; letter-spacing: .05em;
    margin-left: .4rem; vertical-align: middle;
  }
  .pill.ok   { background: #22c55e22; color: #4ade80; }
  .pill.warn { background: #f59e0b22; color: #fbbf24; }
  .pill.fail { background: #ef444422; color: #f87171; }

  /* Info box */
  .info-box {
    background: #1e1e2e;
    border: 1px solid #2a2a3a;
    border-left: 3px solid #f59e0b;
    border-radius: 10px;
    padding: 1rem 1.2rem;
    font-size: .825rem;
    color: #94a3b8;
    line-height: 1.7;
    margin-bottom: 1.5rem;
  }
  .info-box code { background: #2a2a3a; padding: .1rem .35rem; border-radius: 4px; color: #fbbf24; }

  /* Server info */
  .server-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
    gap: .5rem;
    margin-bottom: 2rem;
  }
  .server-item {
    background: #1e1e2e;
    border: 1px solid #2a2a3a;
    border-radius: 8px;
    padding: .65rem .9rem;
  }
  .server-key { font-size: .7rem; color: #475569; text-transform: uppercase; letter-spacing: .06em; }
  .server-val { font-size: .825rem; color: #cbd5e1; margin-top: .15rem; word-break: break-all; }
</style>
</head>
<body>
<div class="container">

  <div class="header">
    <h1>🛠 Deployment Health Check</h1>
    <p>Diagnosa setup backend secara otomatis &mdash; <?= date('d M Y H:i:s') ?></p>
  </div>

  <?php
  $circleClass = $score >= 80 ? 'great' : ($score >= 50 ? 'warn' : 'danger');
  $statusText  = $score >= 80 ? 'Setup terlihat OK!' : ($score >= 50 ? 'Ada beberapa masalah' : 'Banyak yang perlu diperbaiki');
  ?>

  <!-- Score Card -->
  <div class="score-card">
    <div class="score-circle <?= $circleClass ?>">
      <span class="num"><?= $score ?></span>
      <span class="pct">/ 100</span>
    </div>
    <div class="score-info">
      <h2><?= $statusText ?></h2>
      <div class="badges">
        <span class="badge ok">✓ <?= $oks ?> OK</span>
        <?php if ($warns): ?><span class="badge warn">⚠ <?= $warns ?> Warning</span><?php endif; ?>
        <?php if ($fails): ?><span class="badge fail">✗ <?= $fails ?> Error</span><?php endif; ?>
      </div>
    </div>
  </div>

  <!-- Warning -->
  <div class="info-box">
    ⚠ <strong>Penting:</strong> Hapus file <code>check.php</code> ini dari server setelah selesai diagnosa.
    File ini menampilkan informasi sensitif (DB credentials, konfigurasi server, dsb.) dan tidak boleh dapat diakses publik.
  </div>

  <!-- Checks -->
  <p class="section-title">Hasil Pengecekan (<?= $total ?> item)</p>
  <div class="check-list">
    <?php foreach ($results as $key => $r): ?>
      <?php
      $icon = match($r['status']) {
        'ok'   => '✓',
        'warn' => '⚠',
        'fail' => '✗',
        default => '?'
      };
      ?>
      <div class="check-item">
        <div class="icon <?= $r['status'] ?>"><?= $icon ?></div>
        <div class="check-body">
          <div class="check-label">
            <?= htmlspecialchars($r['label']) ?>
            <span class="pill <?= $r['status'] ?>"><?= strtoupper($r['status']) ?></span>
          </div>
          <?php if ($r['detail']): ?>
            <div class="check-detail"><?= htmlspecialchars($r['detail']) ?></div>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- Server Info -->
  <p class="section-title">Informasi Server</p>
  <div class="server-grid">
    <?php
    $serverInfo = [
      'PHP Version'         => PHP_VERSION,
      'Server Software'     => $_SERVER['SERVER_SOFTWARE'] ?? '-',
      'Server Name'         => $_SERVER['SERVER_NAME'] ?? '-',
      'Document Root'       => $_SERVER['DOCUMENT_ROOT'] ?? '-',
      'Script Path'         => __DIR__,
      'HTTPS'               => $isHttps ? 'Ya ✓' : 'Tidak',
      'Origin Header'       => $_SERVER['HTTP_ORIGIN'] ?? '(tidak ada)',
      'DB Host'             => $env['DB_HOST'] ?? '-',
      'DB Name'             => $env['DB_NAME'] ?? '-',
      'DB User'             => $env['DB_USER'] ?? '-',
      'FRONTEND_URL'        => $env['FRONTEND_URL'] ?? '-',
      'Session Status'      => session_status() === PHP_SESSION_ACTIVE ? 'Active' : 'Inactive',
      'upload_max_filesize' => ini_get('upload_max_filesize'),
      'post_max_size'       => ini_get('post_max_size'),
      'max_execution_time'  => ini_get('max_execution_time') . 's',
      'memory_limit'        => ini_get('memory_limit'),
    ];
    foreach ($serverInfo as $key => $val): ?>
      <div class="server-item">
        <div class="server-key"><?= htmlspecialchars($key) ?></div>
        <div class="server-val"><?= htmlspecialchars($val) ?></div>
      </div>
    <?php endforeach; ?>
  </div>

</div>
</body>
</html>
